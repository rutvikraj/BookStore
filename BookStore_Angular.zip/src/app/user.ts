export class User {
    userid!:string;
    upassword!:string;
}
